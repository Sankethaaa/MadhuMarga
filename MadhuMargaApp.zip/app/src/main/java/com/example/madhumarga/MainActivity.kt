package com.example.madhumarga

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.madhumarga.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnAnalyze.setOnClickListener {
            val input = binding.etObservation.text.toString()

            val result = when {
                input.contains("low activity", true) -> "⚠️ Intervention Needed!"
                input.contains("queen seen", true) -> "✅ Hive Healthy"
                else -> "ℹ️ Monitor Hive"
            }

            binding.tvResult.text = result
        }
    }
}